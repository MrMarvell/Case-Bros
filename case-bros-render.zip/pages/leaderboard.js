import { useEffect, useState } from 'react';

function gems(c) {
  return (Number(c || 0) / 100).toFixed(2);
}

export default function Leaderboard() {
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let mounted = true;
    (async () => {
      try {
        const r = await fetch('/api/leaderboard');
        const data = await r.json();
        if (mounted) setRows(data.leaderboard || []);
      } finally {
        if (mounted) setLoading(false);
      }
    })();
    return () => {
      mounted = false;
    };
  }, []);

  return (
    <div>
      <h1>Leaderboard</h1>
      <p className="muted">Top 50 by gems balance (server-side query).</p>

      {loading ? <p className="muted">Loading…</p> : null}

      <div className="table">
        <div className="trow thead">
          <div>#</div>
          <div>Player</div>
          <div style={{ textAlign: 'right' }}>Gems</div>
        </div>

        {rows.map((r, idx) => (
          <div key={idx} className="trow">
            <div className="muted">{idx + 1}</div>
            <div className="player">
              <img
                className="avatarSmall"
                src={r.avatar || '/api/placeholder.svg?type=item&name=User&rarity=Mil-Spec'}
                alt=""
              />
              <span>{r.display_name}</span>
            </div>
            <div style={{ textAlign: 'right', fontVariantNumeric: 'tabular-nums' }}>{gems(r.gems_cents)}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
