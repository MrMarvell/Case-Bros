import { useEffect, useState } from 'react';
import CaseCard from '../components/CaseCard';

export default function Home() {
  const [cases, setCases] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let mounted = true;
    (async () => {
      try {
        const r = await fetch('/api/cases');
        const data = await r.json();
        if (mounted) setCases(data.cases || []);
      } finally {
        if (mounted) setLoading(false);
      }
    })();
    return () => {
      mounted = false;
    };
  }, []);

  return (
    <div>
      <section className="hero">
        <h1>High-fidelity CS2-style case opening simulator</h1>
        <p className="muted">
          Open realistic cases, get drops with authentic rarity + wear bands, and climb the leaderboard — without
          real-money gambling.
        </p>
        <div className="heroBadges">
          <span className="badge">Steam Login</span>
          <span className="badge">Server-truthful drops</span>
          <span className="badge">Wear + float</span>
          <span className="badge">Market cache</span>
          <span className="badge">Leaderboards + Giveaways</span>
        </div>
      </section>

      <section>
        <h2>Cases</h2>
        {loading ? <p className="muted">Loading cases…</p> : null}

        <div className="grid">
          {cases.map((c) => (
            <CaseCard key={c.id} c={c} />
          ))}
        </div>

        {!loading && cases.length === 0 ? <p className="muted">No cases yet. Run db:seed.</p> : null}
      </section>
    </div>
  );
}
