import { useEffect, useState } from 'react';

function fmt(ts) {
  const d = new Date(ts);
  return d.toLocaleString();
}

export default function Winners() {
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let mounted = true;
    (async () => {
      try {
        const r = await fetch('/api/winners');
        const data = await r.json();
        if (mounted) setRows(data.winners || []);
      } finally {
        if (mounted) setLoading(false);
      }
    })();
    return () => {
      mounted = false;
    };
  }, []);

  return (
    <div>
      <h1>Winners</h1>
      <p className="muted">Recent giveaway winners (server-recorded).</p>

      {loading ? <p className="muted">Loading…</p> : null}

      <div className="stack">
        {rows.map((w, idx) => (
          <div key={idx} className="cardPlain" style={{ display: 'flex', justifyContent: 'space-between', gap: 12 }}>
            <div className="player">
              <img
                className="avatarSmall"
                src={w.avatar || '/api/placeholder.svg?type=item&name=User&rarity=Mil-Spec'}
                alt=""
              />
              <div>
                <div style={{ fontWeight: 800 }}>{w.display_name}</div>
                <div className="muted">
                  Won: <b>{w.title}</b> — {w.prize_text}
                </div>
              </div>
            </div>
            <div className="muted">{fmt(w.picked_at)}</div>
          </div>
        ))}
      </div>

      {!loading && rows.length === 0 ? <p className="muted">No winners yet.</p> : null}
    </div>
  );
}
