import { useRouter } from 'next/router';
import { useEffect, useMemo, useState } from 'react';
import Reel from '../../components/Reel';
import ItemCard from '../../components/ItemCard';

function price(c) {
  return (Number(c || 0) / 100).toFixed(2);
}

function pickRandom(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}

function buildReel(items, winner) {
  const reelLen = 80;
  const winIndex = 60;

  const reel = [];
  for (let i = 0; i < reelLen; i++) {
    reel.push(pickRandom(items));
  }
  reel[winIndex] = winner;

  return { reel, winIndex };
}

export default function CasePage() {
  const router = useRouter();
  const { slug } = router.query;

  const [caseInfo, setCaseInfo] = useState(null);
  const [dropItems, setDropItems] = useState([]);
  const [loading, setLoading] = useState(true);

  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [spinKey, setSpinKey] = useState(0);
  const [reelItems, setReelItems] = useState([]);
  const [winIndex, setWinIndex] = useState(60);
  const [result, setResult] = useState(null);

  const openCost = useMemo(() => {
    if (!caseInfo) return 0;
    return Number(caseInfo.case_price_cents || 0) + Number(caseInfo.key_price_cents || 0);
  }, [caseInfo]);

  useEffect(() => {
    if (!slug) return;
    let mounted = true;

    (async () => {
      setLoading(true);
      setError('');
      try {
        const r = await fetch(`/api/cases/${slug}`);
        const data = await r.json();
        if (!r.ok) throw new Error(data.error || 'Failed to load case');
        if (!mounted) return;

        setCaseInfo(data.case);
        setDropItems(data.items || []);
      } catch (e) {
        if (mounted) setError(String(e.message || e));
      } finally {
        if (mounted) setLoading(false);
      }
    })();

    return () => {
      mounted = false;
    };
  }, [slug]);

  async function openCase() {
    if (!caseInfo) return;
    setBusy(true);
    setError('');
    setResult(null);

    try {
      const r = await fetch('/api/open', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ caseSlug: caseInfo.slug })
      });
      const data = await r.json();

      if (!r.ok) {
        if (data.error === 'AUTH_REQUIRED') throw new Error('Please sign in with Steam first.');
        if (data.error === 'NOT_ENOUGH_GEMS') throw new Error('Not enough gems to open this case.');
        throw new Error(data.error || 'Open failed');
      }

      const winner = {
        ...data.drop.item,
        rarity: data.drop.item.rarity,
        image_url: data.drop.item.image_url
      };

      const { reel, winIndex } = buildReel(dropItems.length ? dropItems : [winner], winner);

      setReelItems(reel);
      setWinIndex(winIndex);
      setResult(data.drop);
      setSpinKey(Date.now());
    } catch (e) {
      setError(String(e.message || e));
    } finally {
      setBusy(false);
    }
  }

  const caseImg =
    caseInfo?.image_url ||
    `/api/placeholder.svg?type=case&name=${encodeURIComponent(caseInfo?.name || 'Case')}&rarity=Mil-Spec`;

  return (
    <div>
      {loading ? <p className="muted">Loading…</p> : null}
      {error ? <p className="error">{error}</p> : null}

      {caseInfo ? (
        <div className="caseHeader">
          <img className="caseImg" src={caseImg} alt="" />
          <div>
            <h1 style={{ marginBottom: 6 }}>{caseInfo.name}</h1>
            <div className="muted">
              Open cost: <b>{price(openCost)}</b> gems
            </div>
            <div style={{ marginTop: 12, display: 'flex', gap: 10, flexWrap: 'wrap' }}>
              <button className="btn primary" onClick={openCase} disabled={busy || !dropItems.length}>
                {busy ? 'Opening…' : 'Open Case'}
              </button>
              <a className="btn" href="#drops">
                View Drops
              </a>
            </div>
            <div className="muted" style={{ marginTop: 10 }}>
              Server returns the real result instantly; the reel animation is UI-only.
            </div>
          </div>
        </div>
      ) : null}

      {reelItems.length ? (
        <div style={{ marginTop: 22 }}>
          <Reel items={reelItems} winningIndex={winIndex} spinKey={spinKey} />
        </div>
      ) : null}

      {result ? (
        <div className="resultBox">
          <h2>Result</h2>
          <ItemCard
            item={result.item}
            subtitle={`${result.wear} • float ${Number(result.float_value).toFixed(4)}${
              result.pattern_index != null ? ` • pattern ${result.pattern_index}` : ''
            } • ${result.price_display} gems`}
            highlight
          />
        </div>
      ) : null}

      <section id="drops" style={{ marginTop: 28 }}>
        <h2>Drops</h2>
        <p className="muted">
          This list is public; weights stay server-side. (In a “pro” build you might hide the exact pool.)
        </p>

        <div className="grid">
          {dropItems.map((it) => (
            <div key={it.id} className="cardPlain">
              <ItemCard item={it} subtitle={it.weapon || ''} />
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
