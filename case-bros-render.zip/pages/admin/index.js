import { useEffect, useState } from 'react';

export default function Admin() {
  const [me, setMe] = useState(null);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  const [title, setTitle] = useState('New Giveaway');
  const [prize, setPrize] = useState('Simulated prize');
  const [startsAt, setStartsAt] = useState(new Date(Date.now() + 5 * 60 * 1000).toISOString().slice(0, 16));
  const [endsAt, setEndsAt] = useState(new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().slice(0, 16));
  const [pickId, setPickId] = useState('');

  async function loadMe() {
    const r = await fetch('/api/me');
    const data = await r.json();
    setMe(data.user || null);
  }

  useEffect(() => {
    loadMe();
  }, []);

  async function createGiveaway() {
    setBusy(true);
    setError('');
    try {
      const r = await fetch('/api/admin/giveaways', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title,
          prize_text: prize,
          starts_at: new Date(startsAt).toISOString(),
          ends_at: new Date(endsAt).toISOString()
        })
      });
      const data = await r.json();
      if (!r.ok) throw new Error(data.error || 'Failed');
      alert(`Created giveaway #${data.giveaway.id}`);
    } catch (e) {
      setError(String(e.message || e));
    } finally {
      setBusy(false);
    }
  }

  async function pickWinner() {
    if (!pickId) return;
    setBusy(true);
    setError('');
    try {
      const r = await fetch(`/api/admin/giveaways/${pickId}/pick-winner`, { method: 'POST' });
      const data = await r.json();
      if (!r.ok) throw new Error(data.error || 'Failed');
      alert(`Winner: ${data.winner.display_name}`);
    } catch (e) {
      setError(String(e.message || e));
    } finally {
      setBusy(false);
    }
  }

  if (me && !me.is_admin) {
    return (
      <div>
        <h1>Admin</h1>
        <p className="error">Admin access required.</p>
      </div>
    );
  }

  if (!me) {
    return (
      <div>
        <h1>Admin</h1>
        <p className="muted">Sign in as an admin SteamID.</p>
      </div>
    );
  }

  return (
    <div>
      <h1>Admin</h1>
      <p className="muted">Server-enforced admin endpoints. Admin SteamIDs come from ADMIN_STEAM_IDS env var.</p>

      {error ? <p className="error">{error}</p> : null}

      <div className="grid2">
        <div className="cardPlain">
          <h2>Create Giveaway</h2>
          <div className="formRow">
            <label className="label">Title</label>
            <input className="input" value={title} onChange={(e) => setTitle(e.target.value)} />
          </div>
          <div className="formRow">
            <label className="label">Prize text</label>
            <input className="input" value={prize} onChange={(e) => setPrize(e.target.value)} />
          </div>
          <div className="formRow">
            <label className="label">Starts at</label>
            <input className="input" type="datetime-local" value={startsAt} onChange={(e) => setStartsAt(e.target.value)} />
          </div>
          <div className="formRow">
            <label className="label">Ends at</label>
            <input className="input" type="datetime-local" value={endsAt} onChange={(e) => setEndsAt(e.target.value)} />
          </div>
          <button className="btn primary" onClick={createGiveaway} disabled={busy}>
            {busy ? 'Working…' : 'Create'}
          </button>
        </div>

        <div className="cardPlain">
          <h2>Pick Winner</h2>
          <p className="muted">Picks a weighted winner from giveaway_entries and records it in giveaway_winners.</p>
          <div className="formRow">
            <label className="label">Giveaway ID</label>
            <input className="input" value={pickId} onChange={(e) => setPickId(e.target.value)} placeholder="e.g. 1" />
          </div>
          <button className="btn" onClick={pickWinner} disabled={busy || !pickId}>
            {busy ? 'Picking…' : 'Pick winner now'}
          </button>
        </div>
      </div>
    </div>
  );
}
