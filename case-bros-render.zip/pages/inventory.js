import { useEffect, useState } from 'react';
import ItemCard from '../components/ItemCard';

function price(c) {
  return (Number(c || 0) / 100).toFixed(2);
}

export default function Inventory() {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  async function load() {
    setLoading(true);
    setError('');
    try {
      const r = await fetch('/api/inventory', { credentials: 'include' });
      const data = await r.json();
      if (!r.ok) {
        if (data.error === 'AUTH_REQUIRED') throw new Error('Please sign in with Steam to view your inventory.');
        throw new Error(data.error || 'Failed');
      }
      setItems(data.items || []);
    } catch (e) {
      setError(String(e.message || e));
      setItems([]);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, []);

  async function sell(id) {
    if (!confirm('Sell this item for its drop-time price?')) return;
    setError('');
    try {
      const r = await fetch(`/api/inventory/${id}/sell`, { method: 'POST' });
      const data = await r.json();
      if (!r.ok) throw new Error(data.error || 'Sell failed');
      await load();
    } catch (e) {
      setError(String(e.message || e));
    }
  }

  return (
    <div>
      <h1>Inventory</h1>
      <p className="muted">
        Every case open creates an inventory row with wear, float, pattern (if special), and the cached Steam price at
        drop-time.
      </p>

      {loading ? <p className="muted">Loading…</p> : null}
      {error ? <p className="error">{error}</p> : null}

      <div className="stack">
        {items.map((it) => (
          <div key={it.id} className="invRow">
            <ItemCard
              item={it}
              subtitle={`${it.wear} • float ${Number(it.float_value).toFixed(4)}${
                it.pattern_index != null ? ` • pattern ${it.pattern_index}` : ''
              } • ${price(it.price_cents_at_drop)} gems`}
            />
            <button className="btn" onClick={() => sell(it.id)}>
              Sell
            </button>
          </div>
        ))}
      </div>

      {!loading && items.length === 0 ? <p className="muted">No items yet. Open a case!</p> : null}
    </div>
  );
}
