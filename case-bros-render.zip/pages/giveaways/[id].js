import { useRouter } from 'next/router';
import { useEffect, useState } from 'react';

function fmt(ts) {
  const d = new Date(ts);
  return d.toLocaleString();
}

export default function GiveawayDetail() {
  const router = useRouter();
  const { id } = router.query;

  const [g, setG] = useState(null);
  const [total, setTotal] = useState(0);
  const [mine, setMine] = useState(0);
  const [entries, setEntries] = useState(1);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  async function load() {
    if (!id) return;
    setError('');
    const r = await fetch(`/api/giveaways/${id}`, { credentials: 'include' });
    const data = await r.json();
    if (!r.ok) {
      setError(data.error || 'Failed to load');
      return;
    }
    setG(data.giveaway);
    setTotal(data.total_entries || 0);
    setMine(data.my_entries || 0);
  }

  useEffect(() => {
    load();
  }, [id]);

  async function enter() {
    setBusy(true);
    setError('');
    try {
      const r = await fetch(`/api/giveaways/${id}/enter`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ entries })
      });
      const data = await r.json();
      if (!r.ok) {
        if (data.error === 'AUTH_REQUIRED') throw new Error('Please sign in with Steam first.');
        if (data.error === 'NOT_ENOUGH_GEMS') throw new Error('Not enough gems to buy entries.');
        throw new Error(data.error || 'Failed');
      }
      await load();
    } catch (e) {
      setError(String(e.message || e));
    } finally {
      setBusy(false);
    }
  }

  return (
    <div>
      <h1>Giveaway</h1>
      {error ? <p className="error">{error}</p> : null}

      {g ? (
        <div className="cardPlain">
          <div style={{ fontWeight: 900, fontSize: 18 }}>{g.title}</div>
          <div className="muted">{g.prize_text}</div>
          <div className="muted" style={{ marginTop: 10 }}>
            Status: <b>{g.status}</b> • Starts: <b>{fmt(g.starts_at)}</b> • Ends: <b>{fmt(g.ends_at)}</b>
          </div>

          <div className="divider" />

          <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap', alignItems: 'center' }}>
            <div className="muted">
              Total entries: <b>{total}</b> • Your entries: <b>{mine}</b>
            </div>

            <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
              <input
                className="input"
                type="number"
                min="1"
                max="10000"
                value={entries}
                onChange={(e) => setEntries(Number(e.target.value))}
                style={{ width: 120 }}
              />
              <button className="btn primary" onClick={enter} disabled={busy}>
                {busy ? 'Entering…' : 'Buy entries'}
              </button>
            </div>
          </div>
        </div>
      ) : (
        <p className="muted">Loading…</p>
      )}
    </div>
  );
}
