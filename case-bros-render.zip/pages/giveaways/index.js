import Link from 'next/link';
import { useEffect, useState } from 'react';

export default function Giveaways() {
  const [giveaways, setGiveaways] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let mounted = true;
    (async () => {
      try {
        const r = await fetch('/api/giveaways');
        const data = await r.json();
        if (mounted) setGiveaways(data.giveaways || []);
      } finally {
        if (mounted) setLoading(false);
      }
    })();
    return () => {
      mounted = false;
    };
  }, []);

  return (
    <div>
      <h1>Giveaways</h1>
      <p className="muted">
        Community giveaways use gem-based entries. Admin can pick weighted winners server-side.
      </p>

      {loading ? <p className="muted">Loading…</p> : null}

      <div className="stack">
        {giveaways.map((g) => (
          <Link key={g.id} href={`/giveaways/${g.id}`} className="cardPlain">
            <div style={{ display: 'flex', justifyContent: 'space-between', gap: 12 }}>
              <div>
                <div style={{ fontWeight: 800 }}>{g.title}</div>
                <div className="muted">{g.prize_text}</div>
              </div>
              <div className="muted">{g.status}</div>
            </div>
          </Link>
        ))}
      </div>

      {!loading && giveaways.length === 0 ? <p className="muted">No giveaways yet.</p> : null}
    </div>
  );
}
