import RarityPill from './RarityPill';

export default function ItemCard({ item, subtitle, highlight }) {
  const img =
    item.image_url || `/api/placeholder.svg?type=item&name=${encodeURIComponent(item.name)}&rarity=${encodeURIComponent(item.rarity)}`;

  return (
    <div className={highlight ? 'itemCard highlight' : 'itemCard'}>
      <img className="itemImg" src={img} alt="" />
      <div className="itemMeta">
        <div className="itemName">{item.name}</div>
        <div className="itemRow">
          <RarityPill rarity={item.rarity} />
          {subtitle ? <span className="muted">{subtitle}</span> : null}
        </div>
      </div>
    </div>
  );
}
