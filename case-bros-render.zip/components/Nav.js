import Link from 'next/link';
import { useState } from 'react';

function formatGems(cents) {
  const n = (Number(cents || 0) / 100).toFixed(2);
  return n;
}

export default function Nav({ user, loading, onLogout }) {
  const [busy, setBusy] = useState(false);

  async function logout() {
    setBusy(true);
    try {
      await fetch('/auth/logout', { method: 'POST' });
      onLogout?.();
    } finally {
      setBusy(false);
    }
  }

  return (
    <header className="nav">
      <div className="container navInner">
        <Link className="brand" href="/">
          Case-Bros
        </Link>

        <nav className="links">
          <Link href="/leaderboard">Leaderboard</Link>
          <Link href="/giveaways">Giveaways</Link>
          <Link href="/winners">Winners</Link>
          <Link href="/inventory">Inventory</Link>
          {user?.is_admin ? <Link href="/admin">Admin</Link> : null}
        </nav>

        <div className="auth">
          {loading ? (
            <span className="muted">Loading…</span>
          ) : user ? (
            <>
              <div className="userBox">
                <img
                  className="avatar"
                  src={user.avatar || '/api/placeholder.svg?type=item&name=User&rarity=Mil-Spec'}
                  alt=""
                />
                <div className="userMeta">
                  <div className="userName">{user.display_name}</div>
                  <div className="muted">{formatGems(user.gems_cents)} gems</div>
                </div>
              </div>
              <button className="btn" onClick={logout} disabled={busy}>
                {busy ? 'Signing out…' : 'Sign out'}
              </button>
            </>
          ) : (
            <a className="btn primary" href="/auth/steam">
              Sign in with Steam
            </a>
          )}
        </div>
      </div>
    </header>
  );
}
