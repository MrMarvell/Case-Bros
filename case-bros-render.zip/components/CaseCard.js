import Link from 'next/link';

function price(c) {
  const n = (Number(c || 0) / 100).toFixed(2);
  return n;
}

export default function CaseCard({ c }) {
  const openCost = Number(c.case_price_cents || 0) + Number(c.key_price_cents || 0);
  const img =
    c.image_url || `/api/placeholder.svg?type=case&name=${encodeURIComponent(c.name)}&rarity=Mil-Spec`;

  return (
    <Link href={`/cases/${c.slug}`} className="card">
      <img className="cardImg" src={img} alt="" />
      <div className="cardBody">
        <div className="cardTitle">{c.name}</div>
        <div className="muted">
          Open cost: <b>{price(openCost)}</b> gems
        </div>
      </div>
    </Link>
  );
}
