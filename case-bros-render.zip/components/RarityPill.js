const COLORS = {
  'mil-spec': '#4b69ff',
  restricted: '#8847ff',
  classified: '#d32ce6',
  covert: '#eb4b4b',
  gold: '#caab05'
};

export default function RarityPill({ rarity }) {
  const key = String(rarity || '').toLowerCase();
  const color = COLORS[key] || '#9aa3af';
  return (
    <span className="pill" style={{ borderColor: color, color }}>
      {rarity}
    </span>
  );
}
