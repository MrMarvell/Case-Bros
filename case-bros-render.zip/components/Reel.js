import { useEffect, useMemo, useRef, useState } from 'react';
import ItemCard from './ItemCard';

const ITEM_W = 220;
const GAP = 12;

export default function Reel({ items, winningIndex, spinKey, onDone }) {
  const wrapRef = useRef(null);
  const [x, setX] = useState(0);
  const [spinning, setSpinning] = useState(false);

  const trackStyle = useMemo(() => {
    return {
      transform: `translateX(${x}px)`,
      transition: spinning ? 'transform 6.2s cubic-bezier(0.12, 0.65, 0.08, 1)' : 'none'
    };
  }, [x, spinning]);

  useEffect(() => {
    if (!items?.length) return;

    // reset
    setSpinning(false);
    setX(0);

    // next paint, start spin
    const t = setTimeout(() => {
      const wrap = wrapRef.current;
      const wrapW = wrap?.offsetWidth || 900;

      const centerOffset = wrapW / 2 - ITEM_W / 2;
      const target = -1 * (winningIndex * (ITEM_W + GAP) - centerOffset);

      setSpinning(true);
      setX(target);

      const done = setTimeout(() => {
        setSpinning(false);
        onDone?.();
      }, 6500);

      return () => clearTimeout(done);
    }, 50);

    return () => clearTimeout(t);
  }, [spinKey]); // rerun when spinKey changes

  return (
    <div className="reelWrap" ref={wrapRef}>
      <div className="reelTrack" style={trackStyle}>
        {items.map((it, idx) => (
          <div key={idx} className="reelSlot" style={{ width: ITEM_W, marginRight: GAP }}>
            <ItemCard item={it} subtitle="" highlight={idx === winningIndex && !spinning} />
          </div>
        ))}
      </div>
      <div className="reelMarker" />
    </div>
  );
}
