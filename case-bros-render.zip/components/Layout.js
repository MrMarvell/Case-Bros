import Nav from './Nav';
import { useUser } from '../lib/useUser';

export default function Layout({ children }) {
  const { user, loading, refresh } = useUser();

  return (
    <div className="appShell">
      <Nav user={user} loading={loading} onLogout={refresh} />
      <main className="container">{children}</main>
      <footer className="footer">
        <div className="muted">
          Case-Bros is a simulator for entertainment and community progression. No real-money gambling, no deposits,
          no withdrawals, no trading. Not affiliated with Valve or Steam.
        </div>
      </footer>
    </div>
  );
}
