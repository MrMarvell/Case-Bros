-- Case-Bros initial schema (Postgres)

-- Migrations table (used by scripts/migrate.js)
CREATE TABLE IF NOT EXISTS migrations (
  id SERIAL PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  applied_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Session table for connect-pg-simple
CREATE TABLE IF NOT EXISTS "session" (
  "sid" varchar NOT NULL COLLATE "default",
  "sess" json NOT NULL,
  "expire" timestamptz(6) NOT NULL
);
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'session_pkey'
  ) THEN
    ALTER TABLE "session" ADD CONSTRAINT "session_pkey" PRIMARY KEY ("sid");
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS "IDX_session_expire" ON "session" ("expire");

-- Users
CREATE TABLE IF NOT EXISTS users (
  id BIGSERIAL PRIMARY KEY,
  steam_id VARCHAR(32) NOT NULL UNIQUE,
  display_name TEXT NOT NULL,
  avatar TEXT,
  gems_cents BIGINT NOT NULL DEFAULT 0,
  streak_day INT NOT NULL DEFAULT 0,
  last_streak_claim_at TIMESTAMPTZ,
  is_admin BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Cases
CREATE TABLE IF NOT EXISTS cases (
  id BIGSERIAL PRIMARY KEY,
  slug TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  image_url TEXT,
  case_price_cents INT NOT NULL DEFAULT 0,
  key_price_cents INT NOT NULL DEFAULT 0,
  active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Items
CREATE TABLE IF NOT EXISTS items (
  id BIGSERIAL PRIMARY KEY,
  name TEXT NOT NULL,
  weapon TEXT,
  rarity TEXT NOT NULL,
  is_special BOOLEAN NOT NULL DEFAULT FALSE,
  image_url TEXT,
  market_hash_base TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT items_name_rarity_unique UNIQUE (name, rarity)
);

-- Case drop table
CREATE TABLE IF NOT EXISTS case_items (
  case_id BIGINT NOT NULL REFERENCES cases(id) ON DELETE CASCADE,
  item_id BIGINT NOT NULL REFERENCES items(id) ON DELETE CASCADE,
  weight INT NOT NULL,
  PRIMARY KEY (case_id, item_id)
);

-- Inventory
CREATE TABLE IF NOT EXISTS inventory (
  id BIGSERIAL PRIMARY KEY,
  user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  item_id BIGINT NOT NULL REFERENCES items(id) ON DELETE RESTRICT,
  wear TEXT NOT NULL,
  float_value REAL NOT NULL,
  pattern_index INT,
  price_cents_at_drop INT NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS inventory_user_created_idx ON inventory (user_id, created_at DESC);

-- Market cache (Steam priceoverview cache)
CREATE TABLE IF NOT EXISTS market_cache (
  market_hash_name TEXT PRIMARY KEY,
  price_cents INT NOT NULL DEFAULT 0,
  icon_url TEXT,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Giveaways
CREATE TABLE IF NOT EXISTS giveaways (
  id BIGSERIAL PRIMARY KEY,
  title TEXT NOT NULL,
  prize_text TEXT NOT NULL,
  tier_required INT NOT NULL DEFAULT 0,
  starts_at TIMESTAMPTZ NOT NULL,
  ends_at TIMESTAMPTZ NOT NULL,
  status TEXT NOT NULL DEFAULT 'scheduled', -- scheduled | live | ended
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Giveaway entries (user -> entries)
CREATE TABLE IF NOT EXISTS giveaway_entries (
  giveaway_id BIGINT NOT NULL REFERENCES giveaways(id) ON DELETE CASCADE,
  user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  entries INT NOT NULL DEFAULT 0,
  PRIMARY KEY (giveaway_id, user_id)
);

-- Giveaway winner (1 winner per giveaway in MVP)
CREATE TABLE IF NOT EXISTS giveaway_winners (
  giveaway_id BIGINT PRIMARY KEY REFERENCES giveaways(id) ON DELETE CASCADE,
  user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  picked_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
