const { refreshMarketPrice } = require('../lib/marketCache');

function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

async function refreshStaleBatch(pool) {
  const ttlHours = Number(process.env.MARKET_TTL_HOURS || 3);
  const batch = Number(process.env.MARKET_REFRESH_BATCH || 50);
  const safeBatch = Number.isFinite(batch) && batch > 0 ? Math.min(batch, 200) : 50;

  const res = await pool.query(
    `
    SELECT market_hash_name
    FROM market_cache
    WHERE updated_at < NOW() - ($1 || ' hours')::interval
    ORDER BY updated_at ASC
    LIMIT $2;
    `,
    [String(ttlHours), safeBatch]
  );

  for (const row of res.rows) {
    try {
      await refreshMarketPrice(pool, row.market_hash_name);
      // Gentle pacing to reduce rate-limit risk.
      await sleep(300);
    } catch (err) {
      console.error('refreshStaleBatch error:', err);
      await sleep(600);
    }
  }
}

module.exports = { refreshStaleBatch };
