require('dotenv').config();

const { Client } = require('pg');

async function upsertCase(client, c) {
  const res = await client.query(
    `
    INSERT INTO cases (slug, name, image_url, case_price_cents, key_price_cents, active)
    VALUES ($1, $2, $3, $4, $5, $6)
    ON CONFLICT (slug)
    DO UPDATE SET
      name = EXCLUDED.name,
      image_url = EXCLUDED.image_url,
      case_price_cents = EXCLUDED.case_price_cents,
      key_price_cents = EXCLUDED.key_price_cents,
      active = EXCLUDED.active,
      updated_at = NOW()
    RETURNING *;
    `,
    [c.slug, c.name, c.image_url || null, c.case_price_cents, c.key_price_cents, c.active ?? true]
  );
  return res.rows[0];
}

async function upsertItem(client, i) {
  const res = await client.query(
    `
    INSERT INTO items (name, weapon, rarity, is_special, image_url, market_hash_base)
    VALUES ($1, $2, $3, $4, $5, $6)
    ON CONFLICT (name, rarity)
    DO UPDATE SET
      weapon = EXCLUDED.weapon,
      is_special = EXCLUDED.is_special,
      image_url = EXCLUDED.image_url,
      market_hash_base = EXCLUDED.market_hash_base,
      updated_at = NOW()
    RETURNING *;
    `,
    [i.name, i.weapon || null, i.rarity, !!i.is_special, i.image_url || null, i.market_hash_base]
  );
  return res.rows[0];
}

async function setCaseItems(client, caseId, entries) {
  await client.query('DELETE FROM case_items WHERE case_id = $1;', [caseId]);
  for (const e of entries) {
    await client.query(
      'INSERT INTO case_items (case_id, item_id, weight) VALUES ($1, $2, $3);',
      [caseId, e.item_id, e.weight]
    );
  }
}

async function upsertGiveaway(client, g) {
  const res = await client.query(
    `
    INSERT INTO giveaways (title, prize_text, tier_required, starts_at, ends_at, status)
    VALUES ($1, $2, $3, $4, $5, $6)
    RETURNING *;
    `,
    [g.title, g.prize_text, g.tier_required ?? 0, g.starts_at, g.ends_at, g.status ?? 'live']
  );
  return res.rows[0];
}

async function main() {
  if (!process.env.DATABASE_URL) {
    console.error('DATABASE_URL is required.');
    process.exit(1);
  }

  const ssl = process.env.DATABASE_SSL === 'true' ? { rejectUnauthorized: false } : undefined;
  const client = new Client({ connectionString: process.env.DATABASE_URL, ssl });
  await client.connect();

  // ---- Seed cases ----
  const starterCase = await upsertCase(client, {
    slug: 'starter-case',
    name: 'Starter Case',
    image_url: null,
    case_price_cents: 1000,
    key_price_cents: 2500,
    active: true
  });

  const proCase = await upsertCase(client, {
    slug: 'pro-case',
    name: 'Pro Case',
    image_url: null,
    case_price_cents: 2500,
    key_price_cents: 4000,
    active: true
  });

  // ---- Seed items ----
  const items = [
    // Starter Case
    { name: 'MP9 | Rose Iron', weapon: 'MP9', rarity: 'Mil-Spec', is_special: false, market_hash_base: 'MP9 | Rose Iron' },
    { name: 'P250 | Steel Disruption', weapon: 'P250', rarity: 'Mil-Spec', is_special: false, market_hash_base: 'P250 | Steel Disruption' },
    { name: 'M4A1-S | Nitro', weapon: 'M4A1-S', rarity: 'Restricted', is_special: false, market_hash_base: 'M4A1-S | Nitro' },
    { name: 'AK-47 | Redline', weapon: 'AK-47', rarity: 'Classified', is_special: false, market_hash_base: 'AK-47 | Redline' },
    { name: 'AWP | Asiimov', weapon: 'AWP', rarity: 'Covert', is_special: false, market_hash_base: 'AWP | Asiimov' },

    // Pro Case
    { name: 'USP-S | Cortex', weapon: 'USP-S', rarity: 'Restricted', is_special: false, market_hash_base: 'USP-S | Cortex' },
    { name: 'Desert Eagle | Printstream', weapon: 'Desert Eagle', rarity: 'Classified', is_special: false, market_hash_base: 'Desert Eagle | Printstream' },
    { name: 'M4A4 | The Emperor', weapon: 'M4A4', rarity: 'Classified', is_special: false, market_hash_base: 'M4A4 | The Emperor' },
    { name: 'AK-47 | Neon Rider', weapon: 'AK-47', rarity: 'Covert', is_special: false, market_hash_base: 'AK-47 | Neon Rider' },

    // Gold (special)
    { name: '★ Karambit | Doppler', weapon: 'Knife', rarity: 'Gold', is_special: true, market_hash_base: '★ Karambit | Doppler' },
    { name: '★ Sport Gloves | Vice', weapon: 'Gloves', rarity: 'Gold', is_special: true, market_hash_base: '★ Sport Gloves | Vice' }
  ];

  const inserted = {};
  for (const i of items) {
    const row = await upsertItem(client, i);
    inserted[i.name + '::' + i.rarity] = row;
  }

  // ---- Drop tables with weights ----
  await setCaseItems(client, starterCase.id, [
    { item_id: inserted['MP9 | Rose Iron::Mil-Spec'].id, weight: 1000 },
    { item_id: inserted['P250 | Steel Disruption::Mil-Spec'].id, weight: 1000 },
    { item_id: inserted['M4A1-S | Nitro::Restricted'].id, weight: 240 },
    { item_id: inserted['AK-47 | Redline::Classified'].id, weight: 60 },
    { item_id: inserted['AWP | Asiimov::Covert'].id, weight: 12 },
    { item_id: inserted['★ Karambit | Doppler::Gold'].id, weight: 1 }
  ]);

  await setCaseItems(client, proCase.id, [
    { item_id: inserted['USP-S | Cortex::Restricted'].id, weight: 500 },
    { item_id: inserted['Desert Eagle | Printstream::Classified'].id, weight: 120 },
    { item_id: inserted['M4A4 | The Emperor::Classified'].id, weight: 120 },
    { item_id: inserted['AK-47 | Neon Rider::Covert'].id, weight: 20 },
    { item_id: inserted['★ Sport Gloves | Vice::Gold'].id, weight: 1 }
  ]);

  // ---- Giveaways ----
  // For a seed, we just insert one live giveaway if none exist.
  const existingGiveaways = await client.query('SELECT id FROM giveaways LIMIT 1;');
  if (existingGiveaways.rowCount === 0) {
    const now = new Date();
    const starts = new Date(now.getTime() - 60 * 60 * 1000);
    const ends = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);
    await upsertGiveaway(client, {
      title: 'Weekly Community Giveaway',
      prize_text: '1× Pro Case Bundle (simulated)',
      tier_required: 0,
      starts_at: starts.toISOString(),
      ends_at: ends.toISOString(),
      status: 'live'
    });
  }

  await client.end();
  console.log('Seed complete.');
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
